﻿function firstPageDataEng()
{
	//load all data from js file.
		document.getElementsByTagName("h1")[0].innerHTML = gameData[0].sentBuildTitleE;
		document.getElementsByTagName("h5")[0].innerHTML = gameData[0].sentBuildSubtitleE;
		document.getElementsByTagName("button")[0].innerHTML = gameData[0].playE;
	
}



function secondPageData()
{
	//load all data from js file.
	document.getElementById("btn00").innerHTML = gameData[0].nextE;
	document.getElementById("btn01").innerHTML = gameData[0].startE;
}


var questionIdForQuestn;

var allSentencesFromWords = [];		//get All data from js file
var changeSentenceId = false;		//to show new sentence if flag is true
var maxSentId;						//get maximum sentence id from js file
var minSentId;						// get minimum sentence id from js file
var RandomsentenceId;				// select any radom number between maxSentId and minSentId, and used as sentence id
var questionsWord = [];		//this list for only question words
var answerOnButton = [];		//only for answer display on button	
var mainSentence = [];		//only words for main sentence.
var arrayIndexForSent;

function setChangeSentenceFlag()
{
	//set change sentence flag to true when game loaded or one sentence completed.
	//if any data present in question, answer and main sentence list then
	// delete data from that list.
	changeSentenceId = true;
	questionsWord.splice(0,questionsWord.length);
	answerOnButton.splice(0,answerOnButton.length);
	mainSentence.splice(0,mainSentence.length);
	document.getElementById("bd").className = "ChangeFont14 bg";
				
}

function getJsonDataToListAtOnce()
{
		
		//get all data from words list.
		document.getElementById("mainSent").visibility="visible";
		document.getElementById("ImgTag").visibility="visible";
		document.getElementById("quetn").visibility="visible";
						
		document.getElementById("btn00").style.visibility="visible";
		document.getElementById("btn01").style.visibility="visible";
		allSentencesFromWords = words.slice();
			
}

function getFromJson()
{
	
		//get all data in mainSentence, answer and question list from js file
		
		//if changeSentenceId flag is true then show next sentence.
				if(changeSentenceId == true)
				{
					allSentencesFromWords.splice(arrayIndexForSent,1);
					//delete sentence from allSentencesFromWords to avoid 
					//repeated sentence. And over game when all sentence are completed.
					
					changeSentenceId = false; //set flag false for further use
					
					//if allSentencesFromWords list length is 0 then
					//all setentence are completed show some massage to
					//indicate game is over, else show next sentence
					if(allSentencesFromWords.length == 0)
					{
						
						//if game is over then hidde all buttons and dives and 
						//show game over message by adding some new dives.
						document.getElementById("mainSent").style.visibility="hidden";
						document.getElementById("ImgTag").style.visibility="hidden";
						document.getElementById("quetn").style.visibility="hidden";
						document.getElementById("btn00").style.visibility="hidden";
						document.getElementById("btn01").style.visibility="hidden";
						//hidde mainSentence, question, buttons and images to show your game over message.
						
						for(var i=1; i <= lengthList; i++)
						{
							document.getElementById(i).style.visibility="hidden";
							//used to hide all answer buttons.
						}
						
						//add some br tags to add top margin
						var br = document.createElement("br");
						for(var addBr = 0; addBr < 3; addBr++)
						{
							document.getElementById("text").appendChild(br);
						}
						
						//create one label to show Game Over message and add replay button
						var lbl = document.createElement('label');
						lbl.className="textField1";
						lbl.innerHTML = gameData[0].gameOverE;
						document.getElementById("text").appendChild(lbl);
						document.getElementById("text").appendChild(br);
						
						var btn = document.createElement("button");
						btn.innerHTML = gameData[0].restartE;
						btn.id = "replay"
						btn.className="btn btn-default btn-lg";
						document.getElementById("text").appendChild(btn);
						
						//on button click open new page
							$("button").click(function() {
							if(this.id == "replay")
										document.location = 'build_sentence.html';
									})
	
					}
				}
			
			//if allSentencesFromWords length is not empty, list have some data
			//then get any random sentenceId to show new random sentence
			if(allSentencesFromWords.length > 0)
			{
				maxSentId = allSentencesFromWords.length;
				minSentId = 0;
				arrayIndexForSent = Math.floor(Math.random() * (maxSentId - minSentId)) + minSentId;
				RandomsentenceId = allSentencesFromWords[arrayIndexForSent].sentenceId;
			}
			
						
			//Add all elements to list according to word type.
			//if word type is 1 then add that word to mainSentence list
			//word type = 2 for questionsWord list, word type = 3 for answerOnButton list
				for(var  i = 0; i < allSentencesFromWords.length; i++)
				{
					if(allSentencesFromWords[i].sentenceId == RandomsentenceId)
					{
						var j =0;
						while(j < allSentencesFromWords[i].words.length)
						{
							if(allSentencesFromWords[i].words[j].wordType == 2)
							{
								var element = allSentencesFromWords[i].words[j];
								questionsWord.splice(j,1,element);
							}
							else if(allSentencesFromWords[i].words[j].wordType == 1)
							{
								var element = allSentencesFromWords[i].words[j];
								mainSentence.splice(j,1,element);
							}
							else if(allSentencesFromWords[i].words[j].wordType == 3)
							{
								var element = allSentencesFromWords[i].words[j];
								answerOnButton.splice(j,1,element);
								
							}
							j++;
						}
					}
					
				}
								
				//hide all buttons when 1st time displayed on screen. Display those buttons which have some innerHTML or words
				//also set some background color of that buttons.
				for(var btn=1; btn<17; btn++)
				{
					document.getElementById(btn).style.visibility = "hidden";
					document.getElementById(btn).style.background = "#0076B4";
				}
				
				//Change the color of home button and next button background color.
				document.getElementById("btn01").style.background = "transparent";
				document.getElementById("btn00").style.background = "transparent";
				
				
}

//When 1st time show main sentence then use this function
function displayAnswer()
{
	//display Main sentence.
	if(mainSentence.length > 1)
		document.getElementById("mainSent").innerHTML = mainSentence[0].wordStr + " " + mainSentence[1].wordStr;
	else if(mainSentence.length > 0)
		document.getElementById("mainSent").innerHTML = mainSentence[0].wordStr;
}

//If user click on next button then visible all buttons which are hide
//when one sentence is completed.
function enableAllOnNextButtonClick()
{
		for(var i = 1; i < 17; i++)
		{
				document.getElementById(i).style.background = "white";
				document.getElementById(i).disabled = false;
				document.getElementById(i).style.color = "black";
		}
}

var imgflag = false;
var lengthList;
//call this function in Body onload and next button click
function displayOnScreen()
{
		//display all data on the button.
			var pos = 0;
			var randomWordPosOnButton;
				
		for(var i = 1; i < 17; i++)
		{
				document.getElementById(i).style.background = "white";
		}
				
		if(imgflag == true)
		{
			var img1 = document.getElementById("imgT");
			img1.parentNode.removeChild(img1);
			imgflag = false;
		}
			
	
		//to display all questions randomly
		var maxValue = questionsWord.length;	//max queId
		var minValue = 0;	//min queId
		
		//select random question id
		var forQuetn = Math.floor(Math.random() * (maxValue - minValue)) + minValue;
		
		//Display Question.
		if(questionsWord.length > 0)
		{
			document.getElementById("quetn").innerHTML = questionsWord[forQuetn].wordStr;
			//get queId of selected question.  use this value for answer comparison,
			questionIdForQuestn =  questionsWord[forQuetn].queId;

			//if one question is displayed then delete that question from list
			questionsWord.splice(forQuetn,1);
			lengthList = answerOnButton.length;
			//display words on the button.
			for(var i = 1; i <= lengthList; i++)
			{	
			
				randomWordPosOnButton = Math.floor((Math.random() * answerOnButton.length) + 0); 
				document.getElementById(i).style.visibility = "visible";
				document.getElementById(i).innerHTML = answerOnButton[randomWordPosOnButton].wordStr;
				answerOnButton.splice(randomWordPosOnButton,1);
			}
		
		}
		else
		{
				//if sentence complete then show smily image and complete sentence
				document.getElementById("quetn").innerHTML = "";
				var imgtag = document.createElement("img");
				
				imgtag.id = "imgT";
				imgtag.src = "images/smily.jpg";
				imgtag.width="300";
				imgtag.height="200";
				imgtag.class= "img-responsive";				
				document.getElementById("quetn").appendChild(imgtag);
				document.getElementById("quetn").visibility = "visible";
				document.getElementById("bd").className = "ChangeFont0 bg";
							
				$("#imgT").fadeOut();
				$("#imgT").fadeIn();
										
				//disabled all buttons if answer is true.
					for(var i =1; i < 17; i++)
					{		
						document.getElementById(i).style.visibility = "hidden";
						document.getElementById(i).innerHTML = "";
						changeSentenceId = true;
					}
					imgflag = true;
		}
		
		
}

var id1;
function checkAnswer(id)
{
	var wordOnButton;
	var questionIdOfClickedButton;
	var sentenceToDisplay="";
	id1 = id;
	
	var soundEffects = ["O_Oh.mp3","Arechyaaa.mp3"]; //array for the wrong sound files
	var index = Math.floor(Math.random() * (2 - 0)) + 0;  // get random sound file from array
											 
	//get words on clicked button.
	wordOnButton = document.getElementById(id).innerHTML;
	var soundEffects = ["For_wrong1.wav","For_wrong2.wav"];
	var index = Math.floor(Math.random() * (2 - 0)) + 0;
			
	//get the question id of clicked button from the allSentencesFromWords list.
	var j = 0;
	for(var i =0; i < allSentencesFromWords.length; i++)
	{
		j = 0; 
		while(j < allSentencesFromWords[i].words.length)
		{
			if(wordOnButton == allSentencesFromWords[i].words[j].wordStr)
			{
			//if the button word is matched with list wordStr then get the queId from list.
			questionIdOfClickedButton = allSentencesFromWords[i].words[j].queId;
			
			if(questionIdForQuestn == questionIdOfClickedButton)
			{
				
				//check queId for clicked button with the Js file data
				document.getElementById("mainSent").style.color ="#E8528F";
				document.getElementById(id).disabled = true;
				document.getElementById(id).style.color = "#E8528F";
				
				 document.getElementById('click1').src = "soundFile/For_correct.mp3";  //play sound if ans is true
				 document.getElementById('click1').play(); 
										
					//display msg if answer is correct
					var maxValue = 3;	//max queId
					var minValue = 0;	//min queId
					
					//select random question id
					var forMsg = Math.floor(Math.random() * (maxValue - minValue)) + minValue;
					
					$("#mainSent").fadeOut();
					$("#mainSent").fadeIn();
						
					setTimeout(function(){
						document.getElementById("mainSent").style.color ="white";
						
					},1500);
						
					
				
					//add this element to mainSentence because after sorting display this list of element as a answer.
					mainSentence.push(allSentencesFromWords[i].words[j]);
										
					//pass this list for sorting.
					sortArrayByPossition(mainSentence,'position');
					
					displayOnScreen();
					
					//assign all words from list to one variable. Concatenate this all array elements and display on label.
					for(var i =0; i < mainSentence.length; i++)
					{
						sentenceToDisplay += " "+mainSentence[i].wordStr+" ";
					}
					//display all array element on the label.
					document.getElementById("mainSent").innerHTML = sentenceToDisplay;
								
			}
			
			
			else
			{
					//if queId are wrong then animate button to show wrong answer
					document.getElementById(id).style.background = "red";
					document.getElementById('click1').src = "soundFile/" + soundEffects[index];
							document.getElementById('click1').play();				
								
					 document.getElementById(id).className = document.getElementById(id).className + " shake";
					 setTimeout(function(){
					document.getElementById(id).classList.remove("shake");
					document.getElementById(id).style.background = "white";
						}, 500);
			
			} // end of else (ques and ans did not match)
			return;
			}
			j++;
		}//while related to the question
	}//end of for (the whole list)
	
}

//Sort array elements by position.
function sortArrayByPossition(array, key) 
{
	return array.sort(function(a, b) 
	{
			var x = a[key]; var y = b[key];
				return ((x < y) ? -1 : ((x > y) ? 1 : 0));
	});
} 






